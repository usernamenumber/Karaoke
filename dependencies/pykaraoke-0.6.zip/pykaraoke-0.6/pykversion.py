# Version string
PYKARAOKE_VERSION_STRING = "0.6"
